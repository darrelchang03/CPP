Kaggle username: Darrel Chang
Kaggle leaderboard score: 0.73669