#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/aes.h>
#include <openssl/rand.h>
#include <openssl/evp.h>

#define KEY_LENGTH 16
#define BLOCK_SIZE 16

// Since many of the OpenSSL functions operate on byte array parameter
// Helper functions to convert hex -> byte vise versa

void hex_to_bytes(const char *hex_string, unsigned char *byte_array) {
    int len = strlen(hex_string) / 2;
    for(int i = 0; i < len; i++) {
        sscanf(hex_string + 2 * i, "%2hhx", &byte_array[i]);
    }
}

// Unneeded function (Just compared bytes of each key instead of hex form)

// After perfoming functions on byte array, this function converts back to hex to compare keys
// void bytes_to_hex(const unsigned char *byte_array, int len, char *hex_string) {
//     for (int i = 0; i < len; i++) {
//         sprintf(hex_string + 2 * i, "%02x", byte_array[i]);
//     }
// }

int main() {
    const char *plaintext = "This is a top secret.";
    const char *ciphertext_hex = "764aa26b55a4da654df6b19e4bce00f4ed05e09346fb0e762583cb7da2ac93a2";
    const char *iv_hex = "aabbccddeeff00998877665544332211";

    unsigned char key[KEY_LENGTH];
    unsigned char iv[BLOCK_SIZE];
    unsigned char ciphertext[BLOCK_SIZE * 2];

    // Get byte array form of iv
    hex_to_bytes(iv_hex, iv);

    // Get byte array form of ciphertext
    hex_to_bytes(ciphertext_hex, ciphertext);

    FILE *wordlist = fopen("words.txt", "r");
    // If we cannot find file return 1
    if (!wordlist) {
        perror("Error opening wordlist");
        return 1;
    }

    /*
    Iterate through each word in wordlist, using each word as the key for encryption
    If the ciphertext created matches the original ciphertext, then that word is the key
    */
    
    while (fscanf(wordlist, "%s", key) == 1) {

        // Dynamically add # signs according to the words length to make a 128-bit key
        int numPoundSigns = KEY_LENGTH - strlen(key);
        strcat(key, "################" + (16 - numPoundSigns));

        // Initialize aes-128-cbc encryption with key = word from words.txt
        EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
        EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv);

        // Encrypt the plaintext using key from word list
        int len;
        unsigned char encrypted[BLOCK_SIZE];
        EVP_EncryptUpdate(ctx, encrypted, &len, (unsigned char *)plaintext, strlen(plaintext));
        EVP_EncryptFinal_ex(ctx, encrypted + len, &len);

        // If the generated ciphertext matches the given ciphertext -> word used to encrypt = key 
        if (memcmp(encrypted, ciphertext, BLOCK_SIZE) == 0) {
            printf("Key found: %s\n", key);
            break;
        }

        EVP_CIPHER_CTX_free(ctx);
    }

    fclose(wordlist);

    return 0;
}