// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0

Name april = new Name("April", "Jones");
Name twin = (Name)april.clone();

twin.setLast("Smith");

