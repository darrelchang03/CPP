// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0

// Assumes radius is an integer
public int compareTo(Circle other)
{
   return radius - other.radius;
} // compareTo

