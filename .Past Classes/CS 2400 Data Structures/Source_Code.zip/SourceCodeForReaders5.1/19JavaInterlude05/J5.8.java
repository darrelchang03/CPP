// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
public double getArea()
{
   double s = side.doubleValue();
   return s * s;
} // end getArea

