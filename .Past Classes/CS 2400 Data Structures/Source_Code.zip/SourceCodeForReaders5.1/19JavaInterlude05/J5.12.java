// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
public static void displayPair(OrderedPair<?> pair)
{
   System.out.println(pair);
} // end displayPair

