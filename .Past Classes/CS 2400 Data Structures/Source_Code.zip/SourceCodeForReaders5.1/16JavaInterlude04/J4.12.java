// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
nameList.add("Joe");
nameList.add("Jess");
nameList.add("Josh");
nameList.add("Jen");
for (String name : nameList)
   System.out.print(name + " ");
System.out.println();
