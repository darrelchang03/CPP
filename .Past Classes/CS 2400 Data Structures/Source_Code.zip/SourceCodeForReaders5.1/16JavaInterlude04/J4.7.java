// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
Iterator<String> nameIterator = nameList.iterator();
while (nameIterator.hasNext())
   System.out.println(nameIterator.next());
