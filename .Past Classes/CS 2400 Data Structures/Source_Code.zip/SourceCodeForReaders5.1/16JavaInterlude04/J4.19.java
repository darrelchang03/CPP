// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
ListIterator<String> traverse = nameList.listIterator();
System.out.println("nextIndex " + traverse.nextIndex());
System.out.println("hasNext " + traverse.hasNext());
System.out.println("previousIndex " + traverse.previousIndex());
System.out.println("hasPrevious " + traverse.hasPrevious());

System.out.println("next " + traverse.next());
System.out.println("nextIndex " + traverse.nextIndex());
System.out.println("hasNext " + traverse.hasNext());

System.out.println("previousIndex " + traverse.previousIndex());
System.out.println("hasPrevious " + traverse.hasPrevious());
System.out.println("previous " + traverse.previous());
System.out.println("nextIndex " + traverse.nextIndex());
System.out.println("hasNext " + traverse.hasNext());
System.out.println("next " + traverse.next());
