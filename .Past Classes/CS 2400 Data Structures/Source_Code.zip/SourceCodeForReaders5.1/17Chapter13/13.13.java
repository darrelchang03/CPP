// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
public void remove()
{
   throw new UnsupportedOperationException("remove() is not supported " +
                                           "by this iterator");
} // end remove

