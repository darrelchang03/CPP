// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
public boolean hasNext()
{
   return nextPosition < list.getLength();
} // end hasNext

