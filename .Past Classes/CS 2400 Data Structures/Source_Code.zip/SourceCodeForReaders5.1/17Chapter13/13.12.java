// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
public boolean hasNext()
{
   return nextNode != null;
} // end hasNext
