// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
myList.resetTraversal();
while (myList.hasNext())
   System.out.println(myList.next());
