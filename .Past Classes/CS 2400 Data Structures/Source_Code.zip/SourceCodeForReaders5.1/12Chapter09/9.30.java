// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
private class Record
{
   private int first, last;
   
   private Record(int firstIndex, int lastIndex)
   {
      first = firstIndex;
      last = lastIndex;
   } // end constructor
} // end Record

