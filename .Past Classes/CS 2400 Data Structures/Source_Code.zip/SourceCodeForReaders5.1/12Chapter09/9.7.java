// Iterative version.
// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
public static void countDown(int integer)
{
   while (integer >= 1)
   {
      System.out.println(integer);
      integer--;
   } // end while
} // end countDown

