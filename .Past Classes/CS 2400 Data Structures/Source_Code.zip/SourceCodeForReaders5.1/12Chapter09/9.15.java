/** Displays the integers in an array.
    @param array  An array of integers.
    @param first  The index of the first integer displayed.
    @param last   The index of the last integer displayed,
                  0 <= first <= last < array.length.
    @author Frank M. Carrano, Timothy M. Henry
    @version 5.0
*/
public static void displayArray(int[] array, int first, int last)

