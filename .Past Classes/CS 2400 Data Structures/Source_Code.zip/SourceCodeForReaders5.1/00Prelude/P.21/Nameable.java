/**
  @author Frank M. Carrano, Timothy M. Henry
  @version 5.0
*/
public interface Nameable
{
   public void setName(String petName);
   public String getName();
} // end Nameable
