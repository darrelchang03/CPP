/**
   @author Frank M. Carrano, Timothy M. Henry
   @version 5.0
*/
public class Demo
{
   public static void main(String[] args)
   {
      System.out.println(Constants.FEET_PER_METER);
      System.out.println(Constants.MILES_PER_KILOMETER);
   } // end main
} // end Demo
