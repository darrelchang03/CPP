// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
public T getEntry(int givenPosition)
{
   return list.getEntry(givenPosition);
} // end getEntry
