// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0

SortedListInterface<String> nameList = new SortedList<>();
nameList.add("Jamie");
nameList.add("Brenda");
nameList.add("Sarah");
nameList.add("Tom");
nameList.add("Carlos");
