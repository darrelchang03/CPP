// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0

public boolean contains(T anEntry)
{
   return getEntry(anEntry) != null;
} // end contains

