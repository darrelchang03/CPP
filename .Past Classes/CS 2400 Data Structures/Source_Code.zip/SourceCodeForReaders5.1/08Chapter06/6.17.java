// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
public void push(T newEntry)
{
   checkIntegrity();
   stack.add(newEntry);
} // end push

