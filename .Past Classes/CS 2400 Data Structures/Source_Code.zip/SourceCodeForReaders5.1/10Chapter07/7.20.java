// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
public int compareTo(Assignment other)
{
   return date.compareTo(other.date);
} // end compareTo

