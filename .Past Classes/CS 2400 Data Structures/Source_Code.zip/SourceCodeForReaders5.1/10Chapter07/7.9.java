// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
WaitLine customerLine = new WaitLine();
customerLine.simulate(20, 0.5, 5);
customerLine.displayResults();

