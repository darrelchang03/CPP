// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
package DictionaryPackage;
class Entry<K, V>
{
   private K key;
   private V value;
   
// The private constructor and private methods getKey, getValue, and setValue are here.
// Their definitions are in Listing 21-1 of Chapter 21.
} // end Entry

protected final Entry<K, V> AVAILABLE = new Entry<>(null, null);
