@author Frank M. Carrano, Timothy M. Henry
@version 5.0
// Returns true if this bag is full, or false if not.
	private boolean isArrayFull()
	{
		return numberOfEntries >= bag.length;
	} // end isArrayFull
