@author Frank M. Carrano, Timothy M. Henry
@version 5.0
	public boolean isEmpty()
	{
		return numberOfEntries == 0;
	} // end isEmpty

	public int getCurrentSize() 
	{
		return numberOfEntries;
	} // end getCurrentSize

