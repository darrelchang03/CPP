// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
private Node firstNode;       // Head reference to first node
private Node lastNode;        // Tail reference to last node
private int  numberOfEntries; // Number of entries in list

