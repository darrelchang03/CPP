// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
private void initializeDataFields()
{
   firstNode = null;
   lastNode = null;
   numberOfEntries = 0;
} // end initializeDataFields

