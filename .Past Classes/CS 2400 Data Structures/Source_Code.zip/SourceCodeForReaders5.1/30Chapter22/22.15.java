// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
String streetAddress = addressBook.getValue("555-2072");
