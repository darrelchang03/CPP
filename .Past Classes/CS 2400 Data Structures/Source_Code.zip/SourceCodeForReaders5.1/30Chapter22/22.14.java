// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
addressBook.add("555-1264", "150 Main Street");
addressBook.add("555-8132", "75 Center Court");
addressBook.add("555-4294", "205 Ocean Road");
addressBook.add("555-2072", "82 Campus Way");
