// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
addressBook.remove("555-8132");
addressBook.remove("555-4294");
