   /** Removes all entries from this bag.
       @author Frank M. Carrano, Timothy M. Henry
       @version 5.0 */
	public void clear()
	{
		while (!isEmpty()) 
         remove();
	} // end clear
