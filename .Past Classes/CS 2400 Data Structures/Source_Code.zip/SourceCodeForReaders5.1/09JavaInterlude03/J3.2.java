// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
public SquareRootException()
{
   this("Attempted square root of a negative number.");
} // end default constructor

