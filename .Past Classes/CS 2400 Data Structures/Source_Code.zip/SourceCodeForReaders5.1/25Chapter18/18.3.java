// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
public void add(int newPosition, T newEntry)
{
   throw new UnsupportedOperationException("Illegal attempt to add " +
                     "at a specified position within a sorted list.");
} // end add


