// @author Frank M. Carrano, Timothy M. Henry
// @version 5.0
public class LinkedChainSortedList<T extends Comparable<? super T>>
             extends LinkedChainBase<T>
             implements SortedListInterface<T>

