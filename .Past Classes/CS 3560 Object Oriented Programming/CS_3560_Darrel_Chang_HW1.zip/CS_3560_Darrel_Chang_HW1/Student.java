import java.util.*;

public class Student {
    public String name;
    public static int ID;
    public List<String> classList;

    /**
     * @param class The name of class to be added
     */
    public void addClass(String className) {
        
    }

    /**
     * @param class The name of class to be dropped
     */
    public void dropClass(String className) {

    }
    /**
     * Outputs schedule of classes for this student
     */
    public void generateSchedule() {

    }

    /**
     * Generates grades for respective classes this student is in
     * @return List of grades for this students classes
     */
    public String generateReportCard() {
        return "";
    }   
}   
