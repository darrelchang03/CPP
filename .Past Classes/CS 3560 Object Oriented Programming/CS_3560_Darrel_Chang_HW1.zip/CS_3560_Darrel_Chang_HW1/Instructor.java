import java.util.*;

public class Instructor {
    private String name;
    private int ID;
    List<Class> classList;

    /**
     * Sets grade for a student in a specific class
     * @param className name of class
     * @param studentName name of student within the class
     * @param grade grade to be set for that student
     */
    public void assignGrade(String className, String studentName, String grade) {
        
    }

    /**
     * Outputs schedule of this instructor
     */
    public void generateSchedule() {

    }


}
