import java.util.*;

public class LectureHall {
    private String location;
    List<Class> classList;

    /**
     * 
     * @param className class to be added to this lecture halls list of classes
     */
    public void assignClass(Class className) {

    }

    /**
     * Outputs schedule of classes for this lecture hall
     */
    public void generateSchedule() {

    }
}
